// MotorPWMConfig.h
#ifndef MOTOR_PWM_CONFIG_H
#define MOTOR_PWM_CONFIG_H

#define PWM_CHANNEL_A 0
#define PWM_CHANNEL_B 1
#define PWM_FREQ 5000
#define PWM_RESOLUTION 8

#endif